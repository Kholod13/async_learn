﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;

namespace StatFolder
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public class Stat
    {
        public int Words { get; set; }
        public int Lines { get; set; }
        public int Punctuation { get; set; }
        public Stat()
        {
            Words = 0;
            Lines = 0;
            Punctuation = 0;
        }
        public string Words_str { get => Words.ToString(); }
    }
    public partial class MainWindow : Window, IDisposable
    {
        string FolderPath { get; set; }
        Stat stat = new Stat();
        public Stat Stata => stat;
        internal string SelectedPath;
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
        }
        public void Dispose()
        {
            if (SelectedPath != null) { }
        }
        private void TextAnalyseWords(object stat)
        {
            lock (new object())
            {
                if (stat is string text && !string.IsNullOrEmpty(text))
                {
                    string[] wordArray = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    this.stat.Words += wordArray.Length;
                    Thread.Sleep(100);
                }
            }
        }

        private void TextAnalyseRows(object stat)
        {
            lock (new object())
            {
                if (stat is string text && !string.IsNullOrEmpty(text))
                {
                    string[] rowArray = text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                    this.stat.Lines += rowArray.Length;
                    Thread.Sleep(100);
                }
            }
        }
        private void TextAnalyseLetters(object stat)
        {
            lock (new object())
            {
                if (stat is string text && !string.IsNullOrEmpty(text))
                {
                    string separators = ". , ; : – — ‒ … ! ? \"\" '' «» () {} [] <> /";

                    char[] separatorArray = separators.ToCharArray();

                    foreach (char c in text)
                    {
                        if (separatorArray.Contains(c))
                        {
                            this.stat.Punctuation++;
                            Thread.Sleep(100);
                        }
                    }
                }
            }
        }

        private void ButtonCalculate_Click(object sender, RoutedEventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    FolderPath = dialog.SelectedPath;
                    string[] files = Directory.GetFiles(FolderPath, "*.txt", SearchOption.AllDirectories);

                    foreach (var file in files)
                    {
                        string text = File.ReadAllText(file);
                        Thread thread = new Thread(TextAnalyseWords);
                        thread.Start(text);
                        Thread thread1 = new Thread(TextAnalyseRows);
                        thread1.Start(text);
                        Thread thread3 = new Thread(TextAnalyseLetters);
                        thread3.Start(text);
                    }
                }
            }
        }
    }

    internal class FolderBrowserDialog : IDisposable
    {
        internal string SelectedPath;

        public void Dispose()
        {
            if (SelectedPath != null) { }
        }
        internal object ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}
