﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Sp_hw_module03
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private bool stopFibonacci = false;
        public Window1()
        {
            InitializeComponent();
        }

        private void GenerateFibonacciNumbers()
        {

            int a = 0;
            int b = 1;

            while (!stopFibonacci)
            {
                int nextFibonacci = a + b;
                a = b;
                b = nextFibonacci;

                
                Dispatcher.Invoke(() => Output.AppendText(nextFibonacci + "\n"));

                
                Thread.Sleep(1000);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Thread fibonacciThread = new Thread(GenerateFibonacciNumbers);
            fibonacciThread.Start();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Window2 window2 = new Window2();
            window2.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            stopFibonacci = true;
            Output.AppendText("Stop Fib Thread!");
        }
    }
}
