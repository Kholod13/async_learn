﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sp_hw_module03
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isGenerating = false;
        private Thread generatorThread;
        private bool stopFibonacci = false;
        List<int> fibList = new List<int>();
        List<int> primes = new List<int>();
        private bool stopPrimes = false;
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool IsPrime(int num)
        {
            if (num <= 1)
                return false;
            if (num <= 3)
                return true;
            if (num % 2 == 0 || num % 3 == 0)
                return false;

            for (int i = 5; i * i <= num; i += 6)
            {
                if (num % i == 0 || num % (i + 2) == 0)
                    return false;
            }

            return true;
        }

        private void GeneratePrimes(int min, int max)
        {
            
            if (!stopPrimes) {
                int num = 0;
                if (primes.Count > min)
                {
                    num = primes.Count;
                }
                else
                {
                    num = min;
                }
                for (; num <= max && isGenerating; num++)
                {
                    if (IsPrime(num))
                    {
                        primes.Add(num);
                        Application.Current.Dispatcher.Invoke(() => Output.AppendText("N:" + num + " \n"));

                    }
                    Thread.Sleep(400);
                }
            }
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            stopPrimes=false;
            if (!isGenerating)
            {
                int min = string.IsNullOrEmpty(minInput.Text) ? 2 : int.Parse(minInput.Text);
                int max = string.IsNullOrEmpty(maxInput.Text) ? int.MaxValue : int.Parse(maxInput.Text);

                generatorThread = new Thread(() => GeneratePrimes(min, max));
                generatorThread.Start();

                isGenerating = true;
                minInput.IsEnabled = false;
                maxInput.IsEnabled = false;

            }
            else
            {
                isGenerating = false;
                generatorThread.Abort();
                minInput.IsEnabled = true;
                maxInput.IsEnabled = true;

            }
        }

        private void GenerateFibonacciNumbers()
        {

            int a = 0;
            int b = 1;
            
            while (!stopFibonacci)
            {
                int nextFibonacci = a + b;
                a = b;
                b = nextFibonacci;

                if (nextFibonacci != 1)
                {
                    fibList.Add(nextFibonacci);
                }
                Dispatcher.Invoke(() => Output.AppendText("F:" + fibList[fibList.Count] + " \n"));


                Thread.Sleep(1000);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            stopFibonacci = false;
            Thread fibonacciThread = new Thread(GenerateFibonacciNumbers);
            fibonacciThread.Start();
            fibList.Add(1);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            stopFibonacci = true;
            Output.AppendText("Stop Fib Thread!\n");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            stopPrimes = true;
            Output.AppendText("Stop Gen Nums Thread!\n");
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            fibList.Clear();
            primes.Clear();
            Output.AppendText("Restart Threads!\n");
        }
    }
}
